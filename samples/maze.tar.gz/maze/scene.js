'use strict'

var gl;

var segments = []

function expandCanvas() {
    var canvas = document.getElementById('canvas')
    var newWidth = window.innerWidth
    var newHeight = window.innerHeight
    canvas.width = newWidth
    canvas.height = newHeight
    canvas.style.width = newWidth + 'px'
    canvas.style.height = newHeight + 'px'
    gl.viewportWidth = canvas.width;
    gl.viewportHeight = canvas.height;
    render()
}


function initGL(canvas) {
    try {
        gl = canvas.getContext("experimental-webgl");
        expandCanvas()
        gl.viewportWidth = canvas.width;
        gl.viewportHeight = canvas.height;
    } catch (e) {
    }
    if (!gl) {
        alert("no webgl!");
    }
}


function getShader(gl, id) {
    var shaderScript = document.getElementById(id);
    if (!shaderScript) {
        return null;
    }

    var str = "";
    var k = shaderScript.firstChild;
    while (k) {
        if (k.nodeType == 3) {
            str += k.textContent;
        }
        k = k.nextSibling;
    }

    var shader;
    if (shaderScript.type == "x-shader/x-fragment") {
        shader = gl.createShader(gl.FRAGMENT_SHADER);
    } else if (shaderScript.type == "x-shader/x-vertex") {
        shader = gl.createShader(gl.VERTEX_SHADER);
    } else {
        return null;
    }

    gl.shaderSource(shader, str);
    gl.compileShader(shader);

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert(gl.getShaderInfoLog(shader));
        return null;
    }

    return shader;
}


var shaderProgram;

function initShaders() {
    var fragmentShader = getShader(gl, "light-fs");
    var vertexShader = getShader(gl, "light-vs");
    //var fragmentShader = getShader(gl, "shader-fs");
    //var vertexShader = getShader(gl, "shader-vs");

    shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
        alert("Could not initialise shaders");
    }

    gl.useProgram(shaderProgram);

    shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
    gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

    shaderProgram.textureCoordAttribute = gl.getAttribLocation(shaderProgram, "aTextureCoord");
    gl.enableVertexAttribArray(shaderProgram.textureCoordAttribute);

    shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");
    shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");
    shaderProgram.samplerUniform = gl.getUniformLocation(shaderProgram, "uSampler");
}


function handleLoadedTexture(texture) {
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, texture.image);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);

    gl.bindTexture(gl.TEXTURE_2D, null);
}


var mudTexture;
var wallTexture = []

function initTexture(material) {
    var texture = gl.createTexture();
    texture.image = generateTextureImage(material)
    texture.image.onload = function () {
        handleLoadedTexture(texture)
    }
    return texture
}


var mvMatrix = mat4.create();
var mvMatrixStack = [];
var pMatrix = mat4.create();

function mvPushMatrix() {
    var copy = mat4.create();
    mat4.set(mvMatrix, copy);
    mvMatrixStack.push(copy);
}

function mvPopMatrix() {
    if (mvMatrixStack.length == 0) {
        throw "Invalid popMatrix!";
    }
    mvMatrix = mvMatrixStack.pop();
}


function setMatrixUniforms() {
    gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, false, pMatrix);
    gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
}


function degToRad(degrees) {
    return degrees * Math.PI / 180;
}

var keys = {};
function handleKeyDown(e) {
    keys[e.which || e.keyCode] = true;
    e.preventDefault()
    e.stopPropagation()
    return false;
}
function handleKeyUp(e) {
    keys[e.which || e.keyCode] = false;
    e.preventDefault()
    e.stopPropagation()
    return false;
}


var pitch = 0;
var pitchRate = 0;

var yaw = 0;
var yawRate = 0;

var xPos = 0;
var yPos = 0.4;
var zPos = 0;

var speed = 0;

function handle(delta) {
    if (keys[33]) {
        // Page Up
        pitchRate = 0.1;
    } else if (keys[34]) {
        // Page Down
        pitchRate = -0.1;
    } else {
        pitchRate = 0;
    }

    if (keys[37] || keys[65]) {
        // Left cursor key or A
        yawRate = 0.1;
    } else if (keys[39] || keys[68]) {
        // Right cursor key or D
        yawRate = -0.1;
    } else {
        yawRate = 0;
    }

    if (keys[38] || keys[87]) {
        // Up cursor key or W
        speed = 0.003;
    } else if (keys[40] || keys[83]) {
        // Down cursor key
        speed = -0.003;
    } else {
        speed = 0;
    }
}

var worldVertexPositionBuffer = null;
var worldVertexTextureCoordBuffer = null;

function handleLoadedWorld(data) {
    var lines = data.split("\n");
    var vertexCount = 0;
    var vertexPositions = [];
    var vertexTextureCoords = [];
    for (var i in lines) {
        var vals = lines[i].replace(/^\s+/, "").split(/\s+/);
        if (vals.length == 5 && vals[0] != "//") {
            // It is a line describing a vertex; get X, Y and Z first
            vertexPositions.push(parseFloat(vals[0]));
            vertexPositions.push(parseFloat(vals[1]));
            vertexPositions.push(parseFloat(vals[2]));

            // And then the texture coords
            vertexTextureCoords.push(parseFloat(vals[3]));
            vertexTextureCoords.push(parseFloat(vals[4]));

            vertexCount += 1;
        }
    }

    // generate new floor
    for (var x = -64; x < 64; x++) {
        for (var z = -64; z < 64; z++) {
            var cx = 0.1+Math.random()*0.8
            var cy = 0.1+Math.random()*0.8
            var cs = 0.1

            vertexPositions.push(x);
            vertexPositions.push(0);
            vertexPositions.push(z);
            vertexTextureCoords.push(cx);
            vertexTextureCoords.push(cy);
            vertexCount += 1;

            vertexPositions.push(x+1);
            vertexPositions.push(0);
            vertexPositions.push(z);
            vertexTextureCoords.push(cx+cs);
            vertexTextureCoords.push(cy);
            vertexCount += 1;

            vertexPositions.push(x);
            vertexPositions.push(0);
            vertexPositions.push(z+1);
            vertexTextureCoords.push(cx);
            vertexTextureCoords.push(cy+cs);
            vertexCount += 1;

            vertexPositions.push(x+1);
            vertexPositions.push(0);
            vertexPositions.push(z);
            vertexTextureCoords.push(cx+cs);
            vertexTextureCoords.push(cy);
            vertexCount += 1;

            vertexPositions.push(x+1);
            vertexPositions.push(0);
            vertexPositions.push(z+1);
            vertexTextureCoords.push(cx+cs);
            vertexTextureCoords.push(cy+cs);
            vertexCount += 1;

            vertexPositions.push(x);
            vertexPositions.push(0);
            vertexPositions.push(z+1);
            vertexTextureCoords.push(cx);
            vertexTextureCoords.push(cy+cs);
            vertexCount += 1;
        }
    }

    worldVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, worldVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositions), gl.STATIC_DRAW);
    worldVertexPositionBuffer.itemSize = 3;
    worldVertexPositionBuffer.numItems = vertexCount;

    worldVertexTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, worldVertexTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexTextureCoords), gl.STATIC_DRAW);
    worldVertexTextureCoordBuffer.itemSize = 2;
    worldVertexTextureCoordBuffer.numItems = vertexCount;

    generateWalls()
}


function loadWorld() {
    /*
    var request = new XMLHttpRequest();
    request.open("GET", "world.txt");
    request.onreadystatechange = function () {
        if (request.readyState == 4) {
            handleLoadedWorld(request.responseText);
        }
    }
    request.send();
     */

    var d = ''

    d += '-3.0  1.0 -3.0 0.0 6.0\n'
    d += '-3.0  1.0  3.0 0.0 0.0\n'
    d += ' 3.0  1.0  3.0 6.0 0.0\n'
    d += '-3.0  1.0 -3.0 0.0 6.0\n'
    d += ' 3.0  1.0 -3.0 6.0 6.0\n'
    d += ' 3.0  1.0  3.0 6.0 0.0\n'

    handleLoadedWorld(d);
}

function WallSegment(x1, z1, x2, z2, h, type) {

    var vtxPos = []
    var texCoord = []

    //var cx = 0.1+Math.random()*0.8
    //var cy = 0.1+Math.random()*0.8
    //var cs = 1-cx
    var cx = 0
    var cy = 0
    var cs = 1

    vtxPos.push(x1)
    vtxPos.push(0)
    vtxPos.push(z1)
    texCoord.push(cx)
    texCoord.push(cy);

    vtxPos.push(x1)
    vtxPos.push(h)
    vtxPos.push(z1)
    texCoord.push(cx)
    texCoord.push(cy+cs);

    vtxPos.push(x2)
    vtxPos.push(0)
    vtxPos.push(z2)
    texCoord.push(cx+cs)
    texCoord.push(cy);


    vtxPos.push(x2)
    vtxPos.push(0)
    vtxPos.push(z2)
    texCoord.push(cx+cs)
    texCoord.push(cy);

    vtxPos.push(x2)
    vtxPos.push(h)
    vtxPos.push(z2)
    texCoord.push(cx+cs)
    texCoord.push(cy+cs);

    vtxPos.push(x1)
    vtxPos.push(h)
    vtxPos.push(z1)
    texCoord.push(cx)
    texCoord.push(cy+cs);


    this.vposBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vposBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vtxPos), gl.STATIC_DRAW);
    this.vposBuffer.itemSize = 3;
    this.vposBuffer.numItems = 6;

    this.texCoordBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(texCoord), gl.STATIC_DRAW);
    this.texCoordBuf.itemSize = 2;
    this.texCoordBuf.numItems = 6;
    
    this.type = type

    this.render = function() {
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, wallTexture[this.type]);
        gl.uniform1i(shaderProgram.samplerUniform, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuf);
        gl.vertexAttribPointer(shaderProgram.textureCoordAttribute, this.texCoordBuf.itemSize, gl.FLOAT, false, 0, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.vposBuffer);
        gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, this.vposBuffer.itemSize, gl.FLOAT, false, 0, 0);

        setMatrixUniforms();
        gl.drawArrays(gl.TRIANGLES, 0, this.vposBuffer.numItems);

    }

    segments.push(this)
}

var blocks = []
function cb(sx, sy, type) {
    if (sx < 0) sx = 0; else if (sx > 128) sx = 128
    if (sy < 0) sy = 0; else if (sy > 128) sy = 128
    var shift = sy*128 + sx
    blocks[shift]

    var x = sx - 64
    var y = sy - 64
    new WallSegment(x, y, x+1, y, 1, type)
    new WallSegment(x, y, x, y+1, 1, type)
    new WallSegment(x+1, y, x+1, y+1, 1, type)
    new WallSegment(x, y+1, x+1, y+1, 1, type)
}

function cw(sx, sy, dx, dy, len) {
    var type = Math.floor((Math.random() * wallTexture.length))
    for (var i = 0; i < len; i++) {
        cb(sx, sy, type)
        sx += dx
        sy += dy
    }
}

function generateWalls() {
    for (var i = 0; i < 64; i++) {
        var x = Math.floor(Math.random()*32)+28
        var y = Math.floor(Math.random()*32)+28
        var dx = 0, dy = 0
        var len = Math.random() * 16
        var rv = Math.random()
        if (rv < 0.25) dx = 1;
        else if (rv < 0.5) dx = -1;
        else if (rv < 0.75) dy = 1;
        else dy = -1

        cw(x, y, dx, dy, len)
    }
}




function render() {
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    if (worldVertexTextureCoordBuffer == null || worldVertexPositionBuffer == null) {
        return;
    }

    mat4.perspective(45, gl.viewportWidth / gl.viewportHeight, 0.1, 100.0, pMatrix);

    mat4.identity(mvMatrix);

    // move to camera view - pitch, yaw, translate
    mat4.rotate(mvMatrix, degToRad(-pitch), [1, 0, 0]);
    mat4.rotate(mvMatrix, degToRad(-yaw), [0, 1, 0]);
    mat4.translate(mvMatrix, [-xPos, -yPos, -zPos]);


    segments.map( function(s) {
        s.render()
    })

    // bind texture and buffers, draw triangles
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, mudTexture);
    gl.uniform1i(shaderProgram.samplerUniform, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, worldVertexTextureCoordBuffer);
    gl.vertexAttribPointer(shaderProgram.textureCoordAttribute, worldVertexTextureCoordBuffer.itemSize, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, worldVertexPositionBuffer);
    gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, worldVertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);

    setMatrixUniforms();
    gl.drawArrays(gl.TRIANGLES, 0, worldVertexPositionBuffer.numItems);
}


var lastTime = 0;
// Used to make us "jog" up and down as we move forward.
var joggingAngle = 0;

function update() {
    var timeNow = new Date().getTime();
    if (lastTime != 0) {
        var elapsed = timeNow - lastTime;

        if (speed != 0) {
            xPos -= Math.sin(degToRad(yaw)) * speed * elapsed;
            zPos -= Math.cos(degToRad(yaw)) * speed * elapsed;

            joggingAngle += elapsed * 0.6; // 0.6 "fiddle factor" - makes it feel more realistic :-)
            yPos = Math.sin(degToRad(joggingAngle)) / 20 + 0.4
        }

        yaw += yawRate * elapsed;
        pitch += pitchRate * elapsed;

    }
    lastTime = timeNow;
}

var lastFrame = Date.now()
function cycle() {
    var now = Date.now()
    var delta = now - lastFrame
    requestAnimFrame(cycle);
    handle(delta);
    update();
    render();

    lastFrame = now
}



function start() {
    var canvas = document.getElementById("canvas");
    initGL(canvas);
    initShaders();
    // textures
    mudTexture = initTexture(1);
    for (var i = 0; i < 11; i++) {
        wallTexture[i] = initTexture(i);
    }

    loadWorld();

    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    gl.enable(gl.DEPTH_TEST);

    window.onkeydown = handleKeyDown;
    window.onkeyup = handleKeyUp;
    window.addEventListener('resize', expandCanvas, false)

    cycle();
}

